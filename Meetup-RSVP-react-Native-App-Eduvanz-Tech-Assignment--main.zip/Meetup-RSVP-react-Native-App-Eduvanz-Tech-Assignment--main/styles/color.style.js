export const COLOR_THEME = {
    PRIMARY:'#f8f8ff',
    SECONDARY:'rgb(255,148,44)',
    };